package prac_7;

public interface Scalable {

	public void scale( double factor);
}