package prac_7;

public interface Rotatable {

	public void rotate();
}