package prac_7;

public interface Comparable {

	public int compareTo(Rectangle r);
}