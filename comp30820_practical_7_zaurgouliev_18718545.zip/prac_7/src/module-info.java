module prac_7 {
}